# Qué es Flexbox

* [W3C](https://www.w3.org/TR/css-flexbox/)
* [CSS Tricks](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)
* [Can I Use](http://caniuse.com/#search=flexbox)