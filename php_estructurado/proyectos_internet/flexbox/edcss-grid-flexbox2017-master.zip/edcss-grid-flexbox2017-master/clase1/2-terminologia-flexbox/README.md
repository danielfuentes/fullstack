#Terminología de flexbox

1. Flex container
2. Flex items (hijos directos del flex container, pseudoelementos y texto).
3. Flex lines
4. Main axis y cross axis
    4.1. Main size, main start, main end
    4.2. Cross size, cross start, cross end.
