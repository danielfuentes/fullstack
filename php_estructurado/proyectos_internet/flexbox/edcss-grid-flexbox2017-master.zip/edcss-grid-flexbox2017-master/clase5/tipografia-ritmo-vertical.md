## Tipografía

* [Modular Scale](http://www.modularscale.com)
* [Type scale](http://type-scale.com/)

## Ritmo vertical

* [Vertical Rhytm Tool](http://soqr.fr/vertical-rhythm/)
* [CSS Vertical Rhytm](https://drewish.com/tools/vertical-rhythm/)
