# Diseño Atómico - Atomic Design

![Atomic Design](http://bradfrost.com/wp-content/uploads/2013/06/atomic-design.png)

* [Artículo](http://bradfrost.com/blog/post/atomic-web-design/)
* [Slides](https://www.slideshare.net/bradfrostweb/atomic-design)
* [Video](https://vimeo.com/67476280)
* [Libro](http://atomicdesign.bradfrost.com/table-of-contents/)
* [Pattern Lab](http://patternlab.io/)
* [This Is Responsive](https://bradfrost.github.io/this-is-responsive/)
