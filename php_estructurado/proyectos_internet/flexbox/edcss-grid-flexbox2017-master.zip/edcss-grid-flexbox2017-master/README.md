# Repositorio del curso de CSS Avanzado: "Grid + Flexbox" de EDteam 2017 impartido por @AlvaroFelipe y @jonmircha

### [Ir al Curso](https://ed.team/cursos/css-avanzado)

![CSS Avanzado: Grid + Flexbox](https://ed.team/sites/default/files/styles/large/public/courses/images/css-avanzado-poster.png?itok=L-BuWLKS)