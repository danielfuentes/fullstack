<?php
printf('<h1>Hola este contenido es cargado vía AJAX con fancybox y tiene código del lado del servidor (PHP)</h1>');