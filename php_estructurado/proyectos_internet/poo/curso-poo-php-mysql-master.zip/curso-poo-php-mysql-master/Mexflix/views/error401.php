<?php 
print('
	<h2 class="p1  error">Error 401: No tienes autorización para este recurso</h2>
	<img class="p1  img-404" src="./public/img/not-found.png" alt="Recurso No Autorizado">
	<input class="button  add  block  mauto" type="button" value="Regresar" onclick="history.back()">
');