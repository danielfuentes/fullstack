<?php 
print('
	</main>
	<script src="./public/js/mexflix.js"></script>
</body>
</html>
');