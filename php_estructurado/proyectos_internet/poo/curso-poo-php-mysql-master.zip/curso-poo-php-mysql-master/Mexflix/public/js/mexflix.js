function reloadPage(url) {
	setTimeout(function (){
		window.location.href = url
	}, 3000)
}