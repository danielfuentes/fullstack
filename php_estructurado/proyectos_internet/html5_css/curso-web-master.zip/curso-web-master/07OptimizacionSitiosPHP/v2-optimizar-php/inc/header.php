<header>
	<h1>Logo de mi sitio</h1>
	<nav>
		<ul>
			<li><a href="index.php">Inicio</a></li>
			<li><a href="acerca.php">Acerca</a></li>
			<li><a href="servicios.php">Servicios</a></li>
			<li><a href="contacto.php">Contacto</a></li>
		</ul>
	</nav>
</header>