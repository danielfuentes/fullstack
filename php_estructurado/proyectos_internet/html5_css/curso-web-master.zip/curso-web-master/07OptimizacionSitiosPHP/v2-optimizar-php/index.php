<!DOCTYPE html>
<html lang="es">
<head>
	<?php require 'inc/metatags.php'; ?>
	<title>Inicio</title>
</head>
<body>
	<?php require 'inc/header.php'; ?>
	<section>
		<p>Aquí va el contenido de mi sección <mark>Inicio</mark></p>
	</section>
	<?php require 'inc/footer.php'; ?>
</body>
</html>