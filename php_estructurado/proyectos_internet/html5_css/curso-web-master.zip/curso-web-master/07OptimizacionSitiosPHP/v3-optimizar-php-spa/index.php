<?php
require 'inc/sitemap.php';
require 'inc/header.php';
require $contenido;
require 'inc/footer.php';