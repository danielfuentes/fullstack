	</section>
	<footer>
		<h6>Términos y condiciones que me importan un carajo =P</h6>
	</footer>
</body>
</html>