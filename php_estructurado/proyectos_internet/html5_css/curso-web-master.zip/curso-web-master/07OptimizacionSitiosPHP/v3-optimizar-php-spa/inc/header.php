<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title><?php printf( $titulo ); ?></title>
	<link rel="stylesheet" href="css/estilos.css">
</head>
<body>
	<header>
	<h1>Logo de mi sitio</h1>
		<nav>
			<ul>
				<li><a href="index.php">Inicio</a></li>
				<li><a href="?p=acerca">Acerca</a></li>
				<li><a href="?p=servicios">Servicios</a></li>
				<li><a href="?p=contacto">Contacto</a></li>
			</ul>
		</nav>
	</header>
	<section>