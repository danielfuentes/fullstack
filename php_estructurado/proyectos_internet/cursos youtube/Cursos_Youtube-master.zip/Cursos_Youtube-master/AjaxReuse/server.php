<?php
// echo json_encode(array('id' => 1,'nombre' => 'luis'));
echo $_POST['nombre'];
 ?>
