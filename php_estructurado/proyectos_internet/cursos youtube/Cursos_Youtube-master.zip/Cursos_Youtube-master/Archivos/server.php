<?php
echo "<pre>";
echo $_POST['nombre'];
print_r($_FILES);
echo "</pre>";
 ?>
