let a = 10; 
const b = 30
let resultado = `La suma de ${a} + ${b} = ${a+b}`;

