# README #

#PHPMailer


##Ejemplo práctico de uso de PHPMailer.


Principales características:
----------------------------

>Probablemente es el código más popular del mundo para el envío de correo electrónico desde PHP !

>Utilizado por muchos proyectos de código abierto : WordPress , 
Drupal , 1CRM , SugarCRM , Yii , Joomla ! y muchos más

>Soporte integrado SMTP - envía sin un servidor de correo local
 
>Enviar mensajes de correo electrónico a múltiples direcciones.
    
>Mensajes de correo electrónico para clientes de correo que no leen de correo electrónico HTML.
    
>Soporte para contenido UTF -8 y 8 bits , base64 , binario.
    
>Autenticación SMTP con el inicio de sesión, NORMAL, NTLM , CRAM- MD5 y XOAUTH2 de Google mecanismos a través de SSL y TLS.
   
>Mensajes de error en 47 idiomas!
    
>DKIM y S / MIME compatible con la firma
    
>Compatible con PHP 5.0 y posterior
  
>¡Mucho más!