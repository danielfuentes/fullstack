<footer class="footer">
    Programamos y nos divertimos! - <?php echo date("Y"); ?>
</footer>
