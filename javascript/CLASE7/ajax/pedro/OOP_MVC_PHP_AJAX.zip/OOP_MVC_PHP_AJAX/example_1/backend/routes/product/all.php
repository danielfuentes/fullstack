<?php
  // require_once("../../controllers/ProductController.php");
  // $productController = new ProductController;
  // $products = $productController->index();
  require_once("../../views/product/all.php");
 ?>
