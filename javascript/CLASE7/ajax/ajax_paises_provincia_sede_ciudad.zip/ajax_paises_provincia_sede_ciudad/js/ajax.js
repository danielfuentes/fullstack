window.onload = function() {

getPaises();

function getPaises() {
	var paises = new XMLHttpRequest();
	paises.onreadystatechange = function() {
		if (paises.readyState == 4 && paises.status == 200) {
			alert(paises.responseText);
			alert(JSON.parse(paises.responseText));
		}
	}
	paises.open("GET", "http://pilote.techo.org/admin/?do=api.getPaises", true);
	paises.send();
}


}
